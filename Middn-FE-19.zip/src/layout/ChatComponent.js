import React from "react";
import Chat from "./chat";

function ChatComponent() {
  return (
    <>
      <Chat />
    </>
  );
}

export default ChatComponent;
