import React from "react";
import Notification from "./notification";

function NotificationComponent() {
  return (
    <>
      <Notification />
    </>
  );
}

export default NotificationComponent;
