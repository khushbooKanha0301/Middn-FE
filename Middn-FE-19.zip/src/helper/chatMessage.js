export const firebaseMessages = {
    CHAT_ROOM: "chat/chat_room/",
    CHAT_USERS: "chat/users/",
    MESSAGES: "messages/",
    UN_READ_COUNT: "unreadcount",
  };