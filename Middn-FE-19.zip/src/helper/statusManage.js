export const firebaseStatus = {
    CHAT_ROOM: "users/",
    CHAT_USERS: "users/",
  };