export const firebaseMessagesEscrow = {
    CHAT_ROOM: "escrow/escrow_room/",
    CHAT_USERS: "escrow/users/",
    MESSAGES: "messages/",
    UN_READ_COUNT: "unreadcount",
  };