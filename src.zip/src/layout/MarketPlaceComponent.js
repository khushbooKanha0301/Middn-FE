import React from "react";
import MarketPlace from "./marketPlace";

function MarketPlaceComponent() {
  return (
    <>
      <MarketPlace />
    </>
  );
}

export default MarketPlaceComponent;
