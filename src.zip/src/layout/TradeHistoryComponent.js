import React from "react";
import TradeHistory from "./tradeHistory";

function TradeHistoryComponent() {
  return (
    <>
      <TradeHistory />
    </>
  );
}

export default TradeHistoryComponent;
