import React from "react";
import Escrow from "./escrow";

function EscrowComponent() {
  return (
    <>
      <Escrow />
    </>
  );
}

export default EscrowComponent;
