import React from "react";
import HomePage from "./homePage";

function HomePageComponent() {
  return (
    <>
      <HomePage />
    </>
  );
}

export default HomePageComponent;
